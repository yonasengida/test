define({
  "name": "EAGLES-API",
  "version": "1.0.0",
  "description": "HTTP API service",
  "title": "API documentation",
  "url": "https://sleepy-savannah-82444.herokuapp.com",
  "sampleUrl": false,
  "defaultVersion": "0.0.0",
  "apidoc": "0.3.0",
  "generator": {
    "name": "apidoc",
    "time": "2017-07-25T14:48:34.047Z",
    "url": "http://apidocjs.com",
    "version": "0.17.6"
  }
});
