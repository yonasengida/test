define({
  "name": "EAGLES-API",
  "version": "1.0.0",
  "description": "HTTP API service",
  "title": "API documentation",
  "url": "http://162.243.114.225:9090",
  "sampleUrl": false,
  "defaultVersion": "0.0.0",
  "apidoc": "0.3.0",
  "generator": {
    "name": "apidoc",
    "time": "2017-06-18T16:05:02.291Z",
    "url": "http://apidocjs.com",
    "version": "0.17.5"
  }
});
