define({
  "name": "EAGLES-API",
  "version": "1.0.0",
  "description": "HTTP API service",
  "title": "API documentation",
  "url": "www.eagles.com/api",
  "sampleUrl": false,
  "defaultVersion": "0.0.0",
  "apidoc": "0.3.0",
  "generator": {
    "name": "apidoc",
    "time": "2017-04-02T20:07:43.284Z",
    "url": "http://apidocjs.com",
    "version": "0.17.5"
  }
});
